# Github Reader

# Binary File Declaration
This file connects to the Github and reads various API endpoints. 
linux_x86_64/bin/github
